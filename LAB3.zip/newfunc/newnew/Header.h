#pragma once
#include "mkl.h"

extern "C" _declspec(dllexport)
void Spline_derivatives(double* x, double* y, int nx, int ny, double* res, double& err)