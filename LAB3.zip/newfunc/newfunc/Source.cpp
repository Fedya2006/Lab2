#include "pch.h"
#include "mkl.h"

extern "C" _declspec(dllexport)
void Spline_derivatives( double* x,  double* y,  int nx,  int ny, double* res, double & err )
{
    try
    {
        MKL_INT dorder[3] = { 1, 0, 1 };

        DFTaskPtr task = new DFTaskPtr();

        double * scoeff = new double[ny * (nx - 1) * DF_PP_CUBIC];

        int status = dfdNewTask1D(&task, nx, x, DF_UNIFORM_PARTITION, ny, y, DF_NO_HINT);
        if (status != DF_STATUS_OK)
        {
            err = status;
            return;
        }
        status = dfdEditPPSpline1D(task, DF_PP_CUBIC, DF_PP_NATURAL, DF_BC_FREE_END, NULL, DF_NO_IC, NULL, scoeff, DF_NO_HINT);
        if (status != DF_STATUS_OK)
        {
            err = status;
            return;
        }
        status = dfdConstruct1D(task, DF_PP_SPLINE, DF_METHOD_STD);
        if (status != DF_STATUS_OK)
        {
            err = status;
            return;
        }
        status = dfdInterpolate1D(task, DF_INTERP, DF_METHOD_PP, nx, x, DF_UNIFORM_PARTITION, 3, dorder, NULL, res, DF_NO_HINT, NULL);
        if (status != DF_STATUS_OK)
        {
            err = status;
            return;
        }
        status = dfDeleteTask(&task);
        if (status != DF_STATUS_OK)
        {
            err = status;
            return;
        }
    }
    catch (int e)
    {
        err = e;
    }

}