#pragma once
#include "mkl.h"

extern "C" _declspec(dllexport)
int Spline_derivatives(double* x, double* y, int nx, int ny, int& thrw)
