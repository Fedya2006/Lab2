﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;

namespace Labaratory1
{
    delegate Vector2 Fv2Vector2(Vector2 v2);
    static class Calc
    {
        public static Vector2 Calc1(Vector2 v2)
        {
            Vector2 res = new Vector2();
            res.X = v2.X;
            res.Y = v2.Y;
            return res;
        }
        public static Vector2 Calc2(Vector2 v2)
        {
            Vector2 res = new Vector2();
            res.X = v2.X * v2.Y;
            res.Y = v2.X / v2.Y;
            return res;
        }
    }
    
    struct DataItem
    {
        public DataItem(Vector2 coord, Vector2 fld)
        {
            Coordinates = coord;
            Field = fld;
        }
        public Vector2 Coordinates { get; set; }
        public Vector2 Field { get; set; }

        public string ToLongString(string format)
        {

            return "Coordinates - " + Coordinates.ToString(format) + "\nVector values - " +
                   Field.ToString(format) + "\nAbs - " + Vector2.Distance(Field, new Vector2(0, 0)).ToString(format) +
                   "\n";
        }

        public override string ToString()
        {
            return $"Type -DataItem\nX - {Coordinates.X}\nY - {Coordinates.Y}\nField1 - {Field.X}\nField1 - {Field.Y}";
        }
    }

    abstract class V4Data:IEnumerable<DataItem>
    {
        public abstract  IEnumerator<DataItem> GetEnumerator();
        
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
        
        public string Name { get; protected set; }
        public DateTime Time { get; protected set; }

        public V4Data()
        {
            
        }
        
        public V4Data(string str, DateTime time)
        {
            Name = str;
            Time = time;
        }
        
        abstract public int Count { get; }
        
        abstract public float MaxFromOrigin { get; }

        abstract public string ToLongString(string format);

        public override string ToString()
        {
            return Name + " " + Time;
        }
    }
    
    class V4DataList : V4Data
    {
        public List<DataItem> List { get; set; }

        public bool SaveAsText(string filename)
        {
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter(filename, false);
                writer.WriteLine(Time.ToString());
                writer.WriteLine(Name);
                for (int i = 0; i < List.Count; i++)
                {
                    writer.WriteLine(List[i].Coordinates.X);
                    writer.WriteLine(List[i].Coordinates.Y);
                    writer.WriteLine(List[i].Field.X);
                    writer.WriteLine(List[i].Field.Y);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if(writer != null)
                    writer.Close();
            }

            return true;
        }

        public bool LoadAsText(string filename, ref V4DataList v4)
        {
            StreamReader read = null;
            v4 = new V4DataList();
            v4.List = new List<DataItem>();
            try
            {
                read = new StreamReader(filename);
                DateTime myDate = DateTime.ParseExact(read.ReadLine(),"dd/MM/yyyy HH:mm:ss",
                    System.Globalization.CultureInfo.InvariantCulture);
                string name = read.ReadLine();
                while (read.Peek() > -1)
                {
                    float x = (float) Convert.ToDouble(read.ReadLine());
                    float y = (float) Convert.ToDouble(read.ReadLine());
                    Vector2 coord = new Vector2(x, y);
                    float fx = (float) Convert.ToDouble(read.ReadLine());
                    float fy = (float) Convert.ToDouble(read.ReadLine());
                    Vector2 val = new Vector2(fx, fy);
                    DataItem temp = new DataItem(coord, val);
                    v4.List.Add(temp);
                }
                v4.Time = myDate;
                v4.Name = name;
            }
            catch
            {
                return false;
            }
            finally
            {
                if(read != null)
                    read.Close();
            }
            return true;
        }
        
        public override IEnumerator<DataItem> GetEnumerator()
        {
            return List.GetEnumerator();
        }
        public V4DataList(string Str, DateTime Time): base(Str, Time)
        {
            List = new List<DataItem>();
        }

        public V4DataList()
        {
            
        }
        private bool Find(List<DataItem> src, ref DataItem Item)
        {
            for (int i = 0; i < List.Count; i++)
                if (List[i].Coordinates.X == Item.Coordinates.X && List[i].Coordinates.Y == Item.Coordinates.Y)
                    return true;
            return false;
        }
        
        public bool Add(DataItem newItem)
        {
            if (!Find(List, ref newItem))
            {
                List.Add(newItem);
                return true;
            }
            else
                return false;
        }

        public int AddDefaults(int nItems, Fv2Vector2 F)
        {
            int sum = 0;
            Random rnd = new Random();
            for (int i = 0; i < nItems; i++)
            {
                float x = rnd.Next();
                float y = rnd.Next();
                Vector2 coordinates = new Vector2(x, y);
                Vector2 result = F(coordinates);
                DataItem newItem = new DataItem(coordinates, result);
                if (Add(newItem))
                    sum++;
            }
            return sum;
        }

        public override int Count
        {
            get
            {
                return List.Count;
            }
        }

        public override float MaxFromOrigin
        {
            get
            {
                float max = -1;
                foreach (DataItem i in List)
                {
                    float dist = Vector2.Distance(i.Coordinates, new Vector2(0, 0));
                    
                    if (dist > max)
                        max = dist;
                }
                return max;
            }
        }

        public override string ToString()
        {
            return
                $"Type - V4DataList\nBase class info: String - {Name}, Date - {Time}\nNumber of elements - {List.Count}";
        }

        public override string ToLongString(string format)
        {
            string sum = $"Type - V4DataList\nBase class info: String - {Name}, Date - {Time}\nNumber of elements - {List.Count}\n";
            foreach (DataItem i in List)
                sum += i.ToLongString(format) + "______________________________________\n";
            return sum;
        }
    }

    class GridEnumerator : IEnumerator<DataItem>
    {
        private int numberX;
        private int numberY;
        private Vector2 steps;
        private Vector2[,] values;
        private int indexX;
        private int indexY;
        private bool begin;
        
        public GridEnumerator(int numX, int numY, Vector2 stepsXY, Vector2[,] vals)
        {
            numberX = numX;
            numberY = numY;
            steps = stepsXY;
            values = vals;
            begin = true;
        }

        public DataItem Current
        {
            get
            {
                if(begin)
                    throw new InvalidOperationException();
                Vector2 coord = new Vector2(indexX * steps.X, indexY * steps.Y);
                DataItem data = new DataItem(coord, values[indexX, indexY]);
                return data;
            }
            
        }

        public bool MoveNext()
        {
            if (values.Length == 0)
            {
                return false;
            }
            else if (begin)
            {
                indexX = 0;
                indexY = 0;
                begin = false;
                return true;
            }
            else if ((indexX * steps.X < (numberX - 1) * steps.X))
            {
                indexX++;
                return true;
            }
            else if ((indexX * steps.X == (numberX - 1) * steps.X) && (indexY * steps.Y < (numberY - 1) * steps.Y))
            {
                indexY++;
                indexX = 0;
                return true;
            }
            else
                return false;
        }

        public void Reset()
        {
            begin = false;
        }

        public void Dispose()
        {
            
        }
        object IEnumerator.Current { get; }
        
    }
    
    class V4DataArray : V4Data
    {
        public int numberX { get; private set; }
        public int numberY { get; private set; }
        public Vector2 steps { get; private set; }
        public Vector2[,] values { get; private set; }
        
        public override IEnumerator<DataItem> GetEnumerator()
        {
            return new GridEnumerator(numberX, numberY, steps, values);
        }
        public bool SaveBinary(string filename, ref V4DataArray v4)
        {
            if (v4 == null)
                v4 = new V4DataArray();
            BinaryWriter writer = null;
            try
            {
                writer = new BinaryWriter(File.Open(filename, FileMode.Create));
                writer.Write(Time.ToString());
                writer.Write(Name);
                writer.Write(numberX);
                writer.Write(numberY);
                writer.Write((double)steps.X);
                writer.Write((double)steps.Y);
                for (int i = 0; i < numberX; i++)
                {
                    for (int j = 0; j < numberX; j++)
                    {
                        writer.Write((double)values[i, j].X);
                        writer.Write((double)values[i, j].Y);
                    }
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
            finally
            {
                if(writer != null)
                    writer.Close();
            }
            return true;
        }

        public bool LoadBinary(string filename, ref V4DataArray v4)
        {
            BinaryReader read = null;
            try
            {
                v4 = new V4DataArray();
                read = new BinaryReader(File.Open(filename, FileMode.Open));
                DateTime myDate = DateTime.ParseExact(read.ReadString(),"dd/MM/yyyy HH:mm:ss",
                    System.Globalization.CultureInfo.InvariantCulture);
                string Name = read.ReadString();
                int numx = read.ReadInt32();
                int numy = read.ReadInt32();
                Vector2 steps = new Vector2((float)read.ReadDouble(), (float)read.ReadDouble());
                Vector2[,] a = new Vector2[numy, numx];
                for (int i = 0; i < numx; i++)
                {
                    for (int j = 0; j < numy; j++)
                    {
                        a[i, j] = new Vector2((float) read.ReadDouble(), (float) read.ReadDouble());
                    }
                }
                
                v4.numberX = numx;
                v4.numberY = numy;
                v4.steps = steps;
                v4.values = a;
                v4.Time = myDate;
                v4.Name = Name;
            }
            catch
            {
                return false;
            }
            finally
            {
                if(read != null)
                    read.Close();
            }
            return true;
        }
        
        public V4DataArray(string Str, DateTime Time, int numX, int numY, Vector2 step, Fv2Vector2 F):
            base(Str, Time)
        {
            Vector2 coord = new Vector2();
            coord.X = -step.X;
            coord.Y = -step.Y;
            values = new Vector2[numY, numX];
            for (int i = 0; i < numY; i++)
            {
                coord.Y += step.Y;
                coord.X = -step.X;
                for (int j = 0; j < numX; j++)
                {
                    coord.X += step.X;

                    Vector2 a = F(coord);
                    values[i, j] = F(coord);
                }
            }

            steps = step;
            numberX = numX;
            numberY = numY;
        }

        public V4DataArray()
        {
            
        }

        public override int Count
        {
            get
            {
                return numberX * numberY;
            }
        }

        public override float MaxFromOrigin
        {
            get
            {
                if ((numberX > 0) && (numberY > 0))
                {
                    Vector2 v1 = new Vector2((numberX - 1) * steps.X, (numberY - 1) * steps.Y);
                    return Vector2.Distance(v1, new Vector2(0, 0));
                }
                return -1;
            }
        }

        public override string ToString()
        {
            return $"V4DataArray\nName - {Name}\nDate - {Time}\nNumber of nodes on the x axis - {numberX}\nNumber of nodes on the y axis - {numberY}\n";
        }

        public override string ToLongString(string format)
        {
            string sum = $"V4DataArray\nName - {Name}\nDate - {Time}\nNumber of nodes on the x axis - {numberX}\nNumber of nodes on the y axis - {numberY}\n";
            for (int i = 0; i < numberY; i++)
            {
                sum += '\n';
                for (int j = 0; j < numberX; j++)
                {
                    sum +=
                        $"X - {j * steps.X}\nY - {i * steps.Y}\nField - " 
                            + values[i, j].ToString(format) + "\nModule - " + Vector2.Distance(values[i,j], new Vector2(0, 0)).ToString(format)
                        + "\n______________________________________\n";
                }    
            }
            return sum;
        }
        public static implicit operator V4DataList (V4DataArray ar)
        {
            
            V4DataList res = new V4DataList(ar.Name, ar.Time);
            for (int i = 0; i < ar.numberY; i++)
                for (int j = 0; j < ar.numberX; j++)
                {
                    Vector2 temp_vec = new Vector2();
                    temp_vec.X = j * ar.steps.X;
                    temp_vec.Y = i * ar.steps.Y;
                    DataItem temp = new DataItem(temp_vec, ar.values[i,j]);
                    res.List.Add(temp);
                }
            return res;
        }
    }
    
    class V4MainCollection
    {
        private List<V4Data> data;

        public float Max
        {
            get
            {
                if (data.Count == 0)
                    return float.NaN;
                IEnumerable<DataItem> temp = (from t in data from k in t select k);
                if (temp.Count() != 0)
                    return temp.Max(k => Vector2.Distance(k.Field, new Vector2(0, 0)));
                else
                    return float.NaN;
            }
        }

        public IEnumerable<DataItem> Sort
        {
            get
            {
                if (data.Count == 0)
                    return null;
                
                IEnumerable<DataItem> result = from collection in data
                    from a in collection
                    select a;
                if (result.Count() != 0)
                    return result.OrderByDescending(i => Vector2.Distance(i.Field, new Vector2(0, 0)));
                else
                    return null;
            }
        }

        public IEnumerable<Vector2> Point
        {
             get
             { 
                 if (data.Count == 0)
                     return null;
                 IEnumerable<Vector2> points = (from i in data
                                                where i.GetType() == typeof(V4DataArray)
                                                from k in i
                                                select k.Coordinates).Except(from i in data
                                                                             where i.GetType() == typeof(V4DataList)
                                                                             from k in i
                                                                              select k.Coordinates);
                 return points;
             }
            
        }
        public V4MainCollection()
        {
            data = new List<V4Data>();
        }
        
        public int Count
        {
            get
            {
                return data.Count;
            }
        }

        public V4Data this[int i]
        {
            get
            {
                return data[i];
            }
        }

        public bool Contains(string id)
        {
            if (data.Count == 0)
                return false;
            foreach (V4Data temp in data)
            {
                if (temp.Name == id)
                    return true;
            }

            return false;
        }

        public bool Add(V4Data v4Data)
        {
            if (!Contains(v4Data.Name))
            {
                data.Add(v4Data);
                return true;
            }
            else
                return false;
        }

        public string ToLongString(string format)
        {
            string sum = "";
            foreach (V4Data temp in data)
            {
                sum = sum +  temp.ToLongString(format) + "\n";
            }
            return sum;
        }
        
        public override string ToString()
        {
            string sum = "";
            foreach (V4Data temp in data)
            {
                sum = sum +  temp.ToString() + "\n";
            }
            return sum;
        }
        
    }
    
    class Program
    {
        static void Method1()
        {
            //V4_DATA_ARRAY
            Vector2 step = new Vector2(1, 1);
            V4DataArray temp1 = new V4DataArray("node1", DateTime.Now, 3, 3, step, Calc.Calc1);
            V4DataArray temp2 = new V4DataArray();
            temp1.SaveBinary("test_arr.bin", ref temp1);
            temp1.LoadBinary("test_arr.bin", ref temp2);
            Console.WriteLine(temp1.ToLongString("f4"));
            Console.WriteLine("===================================================");
            Console.WriteLine(temp2.ToLongString("f4"));
            
            //V4_DATA_LIST
            V4DataArray tmp1 = new V4DataArray("node1", DateTime.Now, 2, 2, step, Calc.Calc1);
            V4DataList tmp2 = tmp1;
            V4DataList tmp3 = new V4DataList();
            tmp2.SaveAsText("test_arr.txt");
            tmp2.LoadAsText("test_arr.txt", ref tmp3);
            Console.WriteLine(tmp2.ToLongString("f4"));
            Console.WriteLine("===================================================");
            Console.WriteLine(tmp3.ToLongString("f4"));
        }
        static void Method2()
        {
            V4MainCollection collection = new V4MainCollection();
            Vector2 step = new Vector2(1, 1);
            V4DataArray temp_arzero = new V4DataArray("node2", DateTime.Now, 0, 0, step, Calc.Calc1);
            V4DataArray temp_ar = new V4DataArray("node1", DateTime.Now, 3, 3, step, Calc.Calc1);
            
            V4DataList temp_ls2 = new V4DataList("node3", DateTime.Now);
            temp_ls2.Add(new DataItem(new Vector2(0, 0), new Vector2(1, 1)));
            temp_ls2.Add(new DataItem(new Vector2(12, -30), new Vector2(32, 32)));
            V4DataList temp_ls3 = new V4DataList("node4", DateTime.Now);
            temp_ls3.Add(new DataItem(new Vector2(1, 1), new Vector2(1, 1)));
            V4DataList temp_lszero = new V4DataList("node5", DateTime.Now);
            
            collection.Add(temp_ar);
            collection.Add(temp_arzero);
            collection.Add(temp_ls2);
            collection.Add(temp_ls3);
            collection.Add(temp_lszero);
            
            Console.WriteLine("Max module in V4MainCollection");
            Console.WriteLine(collection.Max);
            Console.WriteLine("Max module in V4MainCollection FINISHED...");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Sorted modules in V4MainCollection");
            IEnumerable<DataItem> sorted = collection.Sort;
            if(sorted != null)
                foreach (var di in collection.Sort)
                {
                    Console.WriteLine(di.ToLongString("F4"));
                }
            else
                Console.WriteLine("Nothing to sort");
            Console.WriteLine("Sorted modules in V4MainCollection FINISHED");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            
            Console.WriteLine("Point exists in  V4DataArrays but not in V4DataLists in format (x,y)");
            foreach (var di in collection.Point)
            {
                Console.WriteLine(di.ToString());
            }
            Console.WriteLine("Point exists in  V4DataArrays but not in V4DataLists in format (x,y) FINISHED");
            
        }
        static void Main(string[] args)
        {
            
            Console.WriteLine("Method1++++++++++++++++++++++++++++++++++");
            Method1();
            Console.WriteLine();
            Console.WriteLine("Method2++++++++++++++++++++++++++++++++++");
            Method2();
           
        }
    }
}